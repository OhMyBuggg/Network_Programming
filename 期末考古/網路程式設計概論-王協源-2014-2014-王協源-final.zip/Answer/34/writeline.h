#pragma once
#include "writeline_r.h"
